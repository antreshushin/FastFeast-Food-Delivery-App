import { useState } from 'react';
import {
  Box,
  Typography,
  Avatar,
  Paper,
  TextField,
  Button,
  List,
  ListItem,
  ListItemText,
  Divider,
  IconButton
} from '@mui/material';
import { Add as AddIcon, Delete as DeleteIcon, CreditCard as CreditCardIcon } from '@mui/icons-material';

const Profile = () => {
  // Sample user data - in a real app, this would come from an API or context
  const [userData, setUserData] = useState({
    fullName: 'John Doe',
    email: 'john.doe@example.com',
    phoneNumber: '(123) 456-7890',
    profileImage: null, // null means use default image
    addresses: [
      {
        id: 1,
        addressLine1: '123 Main St',
        addressLine2: 'Apt 4B',
        city: 'Boston',
        state: 'MA',
        zip: '02108'
      }
    ],
    cards: [
      {
        id: 1,
        cardholderName: 'John Doe',
        cardNumber: '**** **** **** 1234',
        expiryDate: '12/25',
        cvv: '***',
        billingZip: '02108'
      }
    ]
  });

  const [showAddressForm, setShowAddressForm] = useState(false);
  const [newAddress, setNewAddress] = useState({
    addressLine1: '',
    addressLine2: '',
    city: '',
    state: '',
    zip: ''
  });
  const [addressErrors, setAddressErrors] = useState({});

  const [showCardForm, setShowCardForm] = useState(false);
  const [newCard, setNewCard] = useState({
    cardholderName: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    billingZip: ''
  });
  const [cardErrors, setCardErrors] = useState({});

  const handleAddressInputChange = (e) => {
    const { name, value } = e.target;
    setNewAddress(prev => ({
      ...prev,
      [name]: value
    }));
    if (addressErrors[name]) {
      setAddressErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleCardInputChange = (e) => {
    const { name, value } = e.target;
    setNewCard(prev => ({
      ...prev,
      [name]: value
    }));
    if (cardErrors[name]) {
      setCardErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateAddressForm = () => {
    const newErrors = {};
    if (!newAddress.addressLine1) newErrors.addressLine1 = 'Address Line 1 is required';
    if (!newAddress.city) newErrors.city = 'City is required';
    if (!newAddress.state) newErrors.state = 'State is required';
    if (!newAddress.zip) newErrors.zip = 'ZIP code is required';
    
    setAddressErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateCardForm = () => {
    const newErrors = {};
    if (!newCard.cardholderName) newErrors.cardholderName = 'Cardholder name is required';
    if (!newCard.cardNumber) newErrors.cardNumber = 'Card number is required';
    else if (!/^\d{16}$/.test(newCard.cardNumber)) newErrors.cardNumber = 'Card number must be 16 digits';
    if (!newCard.expiryDate) newErrors.expiryDate = 'Expiry date is required';
    else if (!/^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])$/.test(newCard.expiryDate)) newErrors.expiryDate = 'Expiry date must be in MM/DD format';
    if (!newCard.cvv) newErrors.cvv = 'CVV is required';
    else if (!/^\d{3}$/.test(newCard.cvv)) newErrors.cvv = 'CVV must be 3 digits';
    if (!newCard.billingZip) newErrors.billingZip = 'Billing ZIP is required';
    else if (!/^\d{5}$/.test(newCard.billingZip)) newErrors.billingZip = 'ZIP must be 5 digits';
    
    setCardErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleAddressSubmit = () => {
    if (validateAddressForm()) {
      const newAddressWithId = {
        ...newAddress,
        id: Date.now()
      };
      
      setUserData(prev => ({
        ...prev,
        addresses: [...prev.addresses, newAddressWithId]
      }));

      setNewAddress({
        addressLine1: '',
        addressLine2: '',
        city: '',
        state: '',
        zip: ''
      });
      setShowAddressForm(false);
      setAddressErrors({});
    }
  };

  const handleCardSubmit = () => {
    if (validateCardForm()) {
      const newCardWithId = {
        ...newCard,
        id: Date.now(),
        cardNumber: '**** **** **** ' + newCard.cardNumber.slice(-4),
        cvv: '***'
      };
      
      setUserData(prev => ({
        ...prev,
        cards: [...prev.cards, newCardWithId]
      }));

      setNewCard({
        cardholderName: '',
        cardNumber: '',
        expiryDate: '',
        cvv: '',
        billingZip: ''
      });
      setShowCardForm(false);
      setCardErrors({});
    }
  };

  const handleDeleteAddress = (addressId) => {
    setUserData(prev => ({
      ...prev,
      addresses: prev.addresses.filter(addr => addr.id !== addressId)
    }));
  };

  const handleDeleteCard = (cardId) => {
    setUserData(prev => ({
      ...prev,
      cards: prev.cards.filter(card => card.id !== cardId)
    }));
  };

  return (
    <Box sx={{ 
      width: '100%',
      maxWidth: '100%',
      mx: 'auto', 
      p: 3,
      display: 'flex',
      flexDirection: 'column',
      gap: 3
    }}>
      {/* Profile Image */}
      <Box sx={{ 
        display: 'flex', 
        flexDirection: 'column', 
        alignItems: 'center',
        gap: 2
      }}>
        <Avatar
          src={userData.profileImage}
          sx={{ 
            width: 240,
            height: 240,
            bgcolor: 'grey.300'
          }}
        />
        <Typography variant="h5" component="h1">
          {userData.fullName}
        </Typography>
      </Box>

      {/* Account Details */}
      <Paper elevation={2} sx={{ p: 3 }}>
        <Typography variant="h6" gutterBottom>
          Account Details
        </Typography>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <Typography>
            <strong>Full Name:</strong> {userData.fullName}
          </Typography>
          <Typography>
            <strong>Email:</strong> {userData.email}
          </Typography>
          <Typography>
            <strong>Phone:</strong> {userData.phoneNumber}
          </Typography>
        </Box>
      </Paper>

      {/* Addresses Section */}
      <Paper elevation={2} sx={{ p: 3 }}>
        <Box sx={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          mb: 2
        }}>
          <Typography variant="h6">
            Addresses
          </Typography>
          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={() => setShowAddressForm(true)}
          >
            Add Address
          </Button>
        </Box>

        {/* Address Form */}
        {showAddressForm && (
          <Box sx={{ 
            display: 'flex', 
            flexDirection: 'column', 
            gap: 2,
            mb: 3,
            p: 2,
            bgcolor: 'grey.50',
            borderRadius: 1
          }}>
            <TextField
              label="Address Line 1"
              name="addressLine1"
              value={newAddress.addressLine1}
              onChange={handleAddressInputChange}
              error={!!addressErrors.addressLine1}
              helperText={addressErrors.addressLine1}
              required
              fullWidth
            />
            <TextField
              label="Address Line 2"
              name="addressLine2"
              value={newAddress.addressLine2}
              onChange={handleAddressInputChange}
              fullWidth
            />
            <TextField
              label="City"
              name="city"
              value={newAddress.city}
              onChange={handleAddressInputChange}
              error={!!addressErrors.city}
              helperText={addressErrors.city}
              required
              fullWidth
            />
            <TextField
              label="State"
              name="state"
              value={newAddress.state}
              onChange={handleAddressInputChange}
              error={!!addressErrors.state}
              helperText={addressErrors.state}
              required
              fullWidth
            />
            <TextField
              label="ZIP"
              name="zip"
              value={newAddress.zip}
              onChange={handleAddressInputChange}
              error={!!addressErrors.zip}
              helperText={addressErrors.zip}
              required
              fullWidth
            />
            <Box sx={{ 
              display: 'flex', 
              justifyContent: 'space-between',
              width: '100%'
            }}>
              <Button
                variant="outlined"
                onClick={() => {
                  setShowAddressForm(false);
                  setNewAddress({
                    addressLine1: '',
                    addressLine2: '',
                    city: '',
                    state: '',
                    zip: ''
                  });
                  setAddressErrors({});
                }}
              >
                Cancel
              </Button>
              <Button
                variant="contained"
                onClick={handleAddressSubmit}
              >
                Submit
              </Button>
            </Box>
          </Box>
        )}

        {/* Address List */}
        <List>
          {userData.addresses.map((address, index) => (
            <Box key={address.id}>
              {index > 0 && <Divider />}
              <ListItem
                secondaryAction={
                  <IconButton 
                    edge="end" 
                    aria-label="delete"
                    onClick={() => handleDeleteAddress(address.id)}
                  >
                    <DeleteIcon />
                  </IconButton>
                }
              >
                <ListItemText
                  primary={
                    <Typography variant="body1">
                      {address.addressLine1}
                      {address.addressLine2 && `, ${address.addressLine2}`}
                    </Typography>
                  }
                  secondary={
                    <Typography variant="body2" color="text.secondary">
                      {`${address.city}, ${address.state} ${address.zip}`}
                    </Typography>
                  }
                />
              </ListItem>
            </Box>
          ))}
        </List>
      </Paper>

      {/* Payment Methods Section */}
      <Paper elevation={2} sx={{ p: 3 }}>
        <Box sx={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          mb: 2
        }}>
          <Typography variant="h6">
            Payment Methods
          </Typography>
          <Button
            variant="contained"
            startIcon={<CreditCardIcon />}
            onClick={() => setShowCardForm(true)}
          >
            Add Card
          </Button>
        </Box>

        {/* Card Form */}
        {showCardForm && (
          <Box sx={{ 
            display: 'flex', 
            flexDirection: 'column', 
            gap: 2,
            mb: 3,
            p: 2,
            bgcolor: 'grey.50',
            borderRadius: 1
          }}>
            <TextField
              label="Cardholder Name"
              name="cardholderName"
              value={newCard.cardholderName}
              onChange={handleCardInputChange}
              error={!!cardErrors.cardholderName}
              helperText={cardErrors.cardholderName}
              required
              fullWidth
            />
            <TextField
              label="Card Number"
              name="cardNumber"
              value={newCard.cardNumber}
              onChange={handleCardInputChange}
              error={!!cardErrors.cardNumber}
              helperText={cardErrors.cardNumber}
              required
              fullWidth
              inputProps={{ maxLength: 16 }}
            />
            <TextField
              label="Expiry Date (MM/DD)"
              name="expiryDate"
              value={newCard.expiryDate}
              onChange={handleCardInputChange}
              error={!!cardErrors.expiryDate}
              helperText={cardErrors.expiryDate}
              required
              fullWidth
              inputProps={{ maxLength: 5 }}
            />
            <TextField
              label="CVV"
              name="cvv"
              value={newCard.cvv}
              onChange={handleCardInputChange}
              error={!!cardErrors.cvv}
              helperText={cardErrors.cvv}
              required
              fullWidth
              inputProps={{ maxLength: 3 }}
            />
            <TextField
              label="Billing ZIP"
              name="billingZip"
              value={newCard.billingZip}
              onChange={handleCardInputChange}
              error={!!cardErrors.billingZip}
              helperText={cardErrors.billingZip}
              required
              fullWidth
              inputProps={{ maxLength: 5 }}
            />
            <Box sx={{ 
              display: 'flex', 
              justifyContent: 'space-between',
              width: '100%'
            }}>
              <Button
                variant="outlined"
                onClick={() => {
                  setShowCardForm(false);
                  setNewCard({
                    cardholderName: '',
                    cardNumber: '',
                    expiryDate: '',
                    cvv: '',
                    billingZip: ''
                  });
                  setCardErrors({});
                }}
              >
                Cancel
              </Button>
              <Button
                variant="contained"
                onClick={handleCardSubmit}
              >
                Submit
              </Button>
            </Box>
          </Box>
        )}

        {/* Card List */}
        <List>
          {userData.cards.map((card, index) => (
            <Box key={card.id}>
              {index > 0 && <Divider />}
              <ListItem
                secondaryAction={
                  <IconButton 
                    edge="end" 
                    aria-label="delete"
                    onClick={() => handleDeleteCard(card.id)}
                  >
                    <DeleteIcon />
                  </IconButton>
                }
              >
                <ListItemText
                  primary={
                    <Typography variant="body1">
                      {card.cardholderName}
                    </Typography>
                  }
                  secondary={
                    <Typography variant="body2" color="text.secondary">
                      {`${card.cardNumber} • Expires ${card.expiryDate}`}
                    </Typography>
                  }
                />
              </ListItem>
            </Box>
          ))}
        </List>
      </Paper>
    </Box>
  );
};

export default Profile;

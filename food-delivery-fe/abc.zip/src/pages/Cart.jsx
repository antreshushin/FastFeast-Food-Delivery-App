import { useState } from 'react';
import {
  Container,
  Paper,
  Typography,
  Button,
  Box,
  Grid,
  IconButton,
  Divider,
  useTheme,
  useMediaQuery,
} from '@mui/material';
import { Add, Remove, Delete } from '@mui/icons-material';

// Sample cart items (in a real app, this would come from a state management solution)
const initialCartItems = [];

const Cart = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [cartItems, setCartItems] = useState(initialCartItems);

  const handleQuantityChange = (itemId, change) => {
    setCartItems((prevItems) =>
      prevItems.map((item) =>
        item.id === itemId
          ? { ...item, quantity: Math.max(1, item.quantity + change) }
          : item
      )
    );
  };

  const handleRemoveItem = (itemId) => {
    setCartItems((prevItems) => prevItems.filter((item) => item.id !== itemId));
  };

  const calculateTotal = () => {
    return cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
  };

  return (
    <Box sx={{ 
      width: '100%',
      minHeight: '100%',
      p: { xs: 2, sm: 3, md: 4 },
      backgroundColor: '#f5f5f5'
    }}>
      <Container maxWidth="md" sx={{ p: 0 }}>
        <Typography 
          variant="h4" 
          gutterBottom
          sx={{ 
            fontSize: { xs: '1.5rem', sm: '2rem', md: '2.5rem' },
            fontWeight: 'bold',
            mb: 3
          }}
        >
          Shopping Cart
        </Typography>
        <Paper elevation={3} sx={{ 
          p: { xs: 2, sm: 3 },
          backgroundColor: 'white',
          borderRadius: 2
        }}>
          {cartItems.length === 0 ? (
            <Typography 
              variant="h6" 
              align="center" 
              sx={{ 
                py: 4,
                fontSize: { xs: '1rem', sm: '1.1rem' }
              }}
            >
              Your cart is empty
            </Typography>
          ) : (
            <>
              {cartItems.map((item) => (
                <Box key={item.id}>
                  <Grid 
                    container 
                    spacing={2} 
                    alignItems="center" 
                    sx={{ 
                      py: 2,
                      flexDirection: isMobile ? 'column' : 'row'
                    }}
                  >
                    <Grid item xs={12} sm={3}>
                      <Box
                        component="img"
                        src={item.image}
                        alt={item.name}
                        sx={{ 
                          width: '100%',
                          height: isMobile ? 200 : 150,
                          objectFit: 'cover',
                          borderRadius: 1
                        }}
                      />
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <Typography 
                        variant="h6"
                        sx={{ 
                          fontSize: { xs: '1rem', sm: '1.1rem' },
                          fontWeight: 'bold'
                        }}
                      >
                        {item.name}
                      </Typography>
                      <Typography 
                        variant="body2" 
                        color="text.secondary"
                        sx={{ 
                          fontSize: { xs: '0.8rem', sm: '0.9rem' }
                        }}
                      >
                        ${item.price}
                      </Typography>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <Box sx={{ 
                        display: 'flex', 
                        alignItems: 'center',
                        justifyContent: isMobile ? 'center' : 'flex-start'
                      }}>
                        <IconButton
                          size={isMobile ? 'small' : 'medium'}
                          onClick={() => handleQuantityChange(item.id, -1)}
                        >
                          <Remove />
                        </IconButton>
                        <Typography 
                          sx={{ 
                            mx: 2,
                            fontSize: { xs: '0.9rem', sm: '1rem' }
                          }}
                        >
                          {item.quantity}
                        </Typography>
                        <IconButton
                          size={isMobile ? 'small' : 'medium'}
                          onClick={() => handleQuantityChange(item.id, 1)}
                        >
                          <Add />
                        </IconButton>
                      </Box>
                    </Grid>
                    <Grid item xs={12} sm={2}>
                      <Typography 
                        variant="h6"
                        sx={{ 
                          fontSize: { xs: '1rem', sm: '1.1rem' },
                          fontWeight: 'bold',
                          textAlign: isMobile ? 'center' : 'left'
                        }}
                      >
                        ${(item.price * item.quantity).toFixed(2)}
                      </Typography>
                    </Grid>
                    <Grid item xs={12} sm={1}>
                      <Box sx={{ 
                        display: 'flex',
                        justifyContent: isMobile ? 'center' : 'flex-end'
                      }}>
                        <IconButton
                          color="error"
                          onClick={() => handleRemoveItem(item.id)}
                          size={isMobile ? 'small' : 'medium'}
                        >
                          <Delete />
                        </IconButton>
                      </Box>
                    </Grid>
                  </Grid>
                  <Divider />
                </Box>
              ))}
              <Box sx={{ 
                mt: 3, 
                display: 'flex', 
                justifyContent: 'space-between', 
                alignItems: 'center',
                flexDirection: isMobile ? 'column' : 'row',
                gap: 2
              }}>
                <Typography 
                  variant="h5"
                  sx={{ 
                    fontSize: { xs: '1.2rem', sm: '1.4rem' },
                    fontWeight: 'bold'
                  }}
                >
                  Total: ${calculateTotal().toFixed(2)}
                </Typography>
                <Button 
                  variant="contained" 
                  color="primary" 
                  size="large"
                  fullWidth={isMobile}
                  sx={{ 
                    px: 4,
                    py: 1.5,
                    fontSize: { xs: '1rem', sm: '1.1rem' }
                  }}
                >
                  Proceed to Checkout
                </Button>
              </Box>
            </>
          )}
        </Paper>
      </Container>
    </Box>
  );
};

export default Cart; 
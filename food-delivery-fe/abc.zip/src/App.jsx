import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material';
import CssBaseline from '@mui/material/CssBaseline';
import { useState } from 'react';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import SignIn from './pages/SignIn';
import SignUp from './pages/SignUp';
import Menu from './pages/Menu';
import Cart from './pages/Cart';
import Chains from './pages/Chains';
import Profile from './pages/Profile';
import { Box } from '@mui/material';

// Create a theme instance
const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
  },
});

function App() {
  const [selectedChain, setSelectedChain] = useState('');

  const handleChainSelect = (chainName) => {
    setSelectedChain(chainName);
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Box sx={{ 
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        display: 'flex', 
        flexDirection: 'column', 
        height: '100vh',
        width: '100vw',
        margin: 0,
        padding: 0,
        overflow: 'hidden'
      }}>
        <Router>
          <Navbar />
          <Box component="main" sx={{ 
            flexGrow: 1,
            width: '100%',
            display: 'flex',
            flexDirection: 'column',
            overflow: 'auto'
          }}>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path = "/signin" element={<SignIn />} />
              <Route path = "/signup" element={<SignUp />} />
              <Route path = "/menu" element={<Menu selectedChain={selectedChain} />} />
              <Route path = "/cart" element={<Cart />} />
              <Route path = "/chains" element={<Chains onChainSelect={handleChainSelect} />} />
              <Route path = "/profile" element={<Profile />} />
            </Routes>
          </Box>
        </Router>
      </Box>
    </ThemeProvider>
  );
}

export default App;
